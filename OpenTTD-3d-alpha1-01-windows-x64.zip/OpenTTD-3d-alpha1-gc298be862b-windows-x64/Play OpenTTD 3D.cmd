@echo off
cd /d "%~dp0"
start "" "%~dp0openttd.exe" -c "%~dp0openttd.cfg" -X -QQ -I OpenGFX -v win32-opengl -b 32bpp-optimized -s null -m null
